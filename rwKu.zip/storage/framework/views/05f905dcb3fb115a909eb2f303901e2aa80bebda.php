<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title><?php echo $__env->yieldContent('title'); ?></title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo e(URL::asset('admin/vendors/iconfonts/mdi/css/materialdesignicons.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(URL::asset('admin/vendors/css/vendor.bundle.base.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(URL::asset('admin/vendors/css/vendor.bundle.addons.css')); ?>">
  <!-- endinject -->
  <link rel="stylesheet" href="<?php echo e(URL::asset('admin/vendors/iconfonts/font-awesome/css/font-awesome.css')); ?>">
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/style.css')); ?>">
  <link href="<?php echo e(asset('css/style2.css')); ?>" rel="stylesheet">
  <!-- endinject -->
  <link rel="shortcut icon" href="<?php echo e(URL::asset('admin/images/favicon.png')); ?>" />
</head>

<body>
  <div class="container-scroller">
    <!-- partial:../../partials/_navbar.html -->
    <?php echo $__env->make('admin.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:../../partials/_sidebar.html -->
      <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <?php if(session('errors')): ?>
    				<?php if($errors->any()): ?>
    			    <div style="color: white !important" class="alert bg-warning" role="alert">
    			        ERROR !!
    			      <a href="#" class="pull-right" style="color: white;" data-dismiss="alert" aria-label="Close">
    			        <em class="fa fa-lg fa-close close-alert"></em>
    			      </a>
    			      <ul>
    			        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    			          <li><?php echo e($error); ?></li>
    			        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    			      </ul>
    			    </div>
    			  <?php endif; ?>
    			<?php endif; ?>
    		  <?php if(Session('success')): ?>
    		    <div style="color: white !important" class="alert bg-success" role="alert">
    		      <em class="fa fa-lg fa-check">&nbsp;</em>
    		        <?php echo e(Session('success')); ?>

    		      <a href="#" class="pull-right" style="color: white;" data-dismiss="alert" aria-label="Close">
    		        <em class="fa fa-lg fa-close close-alert"></em>
    		      </a>
    		    </div>
    		  <?php endif; ?>
          <?php if(Session('info')): ?>
            <div style="color: white !important" class="alert bg-info" role="alert">
              <em class="fa fa-lg fa-check">&nbsp;</em>
                <?php echo e(Session('info')); ?>

              <a href="#" class="pull-right" style="color: white;" data-dismiss="alert" aria-label="Close">
                <em class="fa fa-lg fa-close close-alert"></em>
              </a>
            </div>
          <?php endif; ?>          
          <?php echo $__env->yieldContent('content'); ?>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:../../partials/_footer.html -->
        <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018
              <a href="http://www.bootstrapdash.com/" target="_blank">Bootstrapdash</a>. All rights reserved.</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with
              <i class="mdi mdi-heart text-danger"></i>
            </span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="<?php echo e(URL::asset('admin/vendors/js/vendor.bundle.base.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('admin/vendors/js/vendor.bundle.addons.js')); ?>"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="<?php echo e(URL::asset('admin/js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('admin/js/misc.js')); ?>"></script>
  <script src="../../../js/swal/sweetalert.min.js" type="text/javascript"></script>
  <script src="../../../js/swal/swalTool.js" type="text/javascript"></script>

  <!-- endinject -->
  <?php echo $__env->yieldContent('extra-js'); ?>
</body>
</html>
