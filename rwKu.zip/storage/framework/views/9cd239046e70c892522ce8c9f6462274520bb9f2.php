<?php $__env->startSection('title', 'Admin | List Warga'); ?>
<?php $__env->startSection('content'); ?>
  <div class="row" ng-app="myApp" ng-controller="main">
    <div class="col-lg-12 grid-margin stretch-card">
      <div class="card">
        <div class="card-body">
          <h4 class="card-title">Daftar Warga</h4>
          <div class="table-responsive">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Nama Warga</th>
                  <th>Jenis Kelamin</th>
                  <th>RT</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php  $i=1; ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="py-1"><?php echo e($i++); ?></td>
                  <td><?php echo e($item->name); ?></td>
                  <td><?php echo e($item->sex); ?></td>
                  <td><?php echo e($item->rt); ?></td>
                  <td>
                    <button type="button" class="btn btn-outline-info dropdown-toggle btn-sm" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action</button>
                    <div class="dropdown-menu" x-placement="bottom-start">
                        <button class="dropdown-item"><i class="fa fa-th-list mr-2"></i>Detail</button>
                        <button class="dropdown-item"><i class="fa fa-pencil mr-2"></i>Edit</button>             
                        <button class="dropdown-item"><i class="fa fa-trash-o mr-2"></i>Hapus</button>             
                    </div>                    
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

<style type="text/css">
  .dropdown-item{
    padding: 15px !important;
  }
</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?> 
    <script src="../../../js/residenController.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>